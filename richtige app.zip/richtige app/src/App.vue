<script setup>
import BlogIcon from "@/components/icons/IconBlog.vue";
import {ref} from 'vue'

const drawer = ref(true)
</script>

<template>
  <VLayout row wrap rounded rounded-md align-start>
    <VAppBar rounded class="transparent" style="max-height: 500px;">
      <VAppBarNavIcon variant="text" @click.stop="drawer = !drawer"/>
      <v-img src="https://img.fotocommunity.com/der-oktober-in-oberschlesien-e32ecefd-01c4-4e01-ba86-ce08dd23a733.jpg?width=1000" ></v-img>

      <VToolbarTitle>Food Court</VToolbarTitle>


      <VSpacer></VSpacer>
      <VBtn variant="text" icon="mdi-magnify"></VBtn>
      <VBtn variant="text" icon>
        <VIcon>mdi-filter</VIcon>
        <VMenu activator="parent">
          <VList density="compact">
            <VListItem>Italienisch</VListItem>
            <VListItem>Asiatisch</VListItem>
            <VListItem>Mexikanisch</VListItem>
            <VListItem>Deutsch</VListItem>
            <VListItem>fast Food</VListItem>
            <VListItem>Gesund/Vegan</VListItem>
          </VList>
        </VMenu>
      </VBtn>


      <VBtn variant="text" icon>
        <VIcon>mdi-dots-vertical</VIcon>
        <VMenu activator="parent">
          <VList density="compact">
            <VListItem link to="/posts/Profil">Profile </VListItem>
            <VListItem>Settings</VListItem>
          </VList>
        </VMenu>
      </VBtn>
    </VAppBar>




    <VNavigationDrawer mobile-breakpoint="sm" v-model="drawer" class="transparent">

      <VList>
        <VListItem :prepend-icon="BlogIcon" link to="/Home">
          Home
        </VListItem>
        <VListItem prepend-icon="mdi-shape" link to="/Restaurant">
          Restaurant
        </VListItem>
        <VListItem prepend-icon="mdi-account-multiple" link to="/Rezept">
          Rezept
        </VListItem>

      </VList>
    </VNavigationDrawer>

    <VMain>
      <RouterView></RouterView>
    </VMain>
    <VBtn link to="/posts/create"
          variant="elevated" icon="mdi-plus" color="indigo-darken-4"
          position="fixed" size="large" style="bottom:5em; right:3em">
    </VBtn>


  </VLayout>
</template>

