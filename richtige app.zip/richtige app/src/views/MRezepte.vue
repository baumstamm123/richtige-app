<template>
  <div style="display: grid; grid-template-columns: 1fr 1fr;">
    <div>
      <base-card :image="image1">
        <!-- Individuelle Inhalte für die Slots -->
        <template v-slot:header>
          <h2>Salsa</h2>
        </template>
        <template v-slot:subtitle>
          <p>30 min | scharf</p>
        </template>
        <template v-slot:content>
          <p><ul>
            5	Tomaten, geschälte <br>
            2	Paprikaschote(n), rote<br>
            2	Paprikaschote(n), grüne<br>
            3 m.-große	Zwiebel(n)<br>
            2	Chilischote(n)<br>
            1	Zitrone(n), Saft davon<br>
            1 EL, gestr.	Salz<br>
            2 EL	Zucker<br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </base-card>
    </div>

    <div>
      <base-card :image="image2">
        <!-- Individuelle Inhalte für die Slots -->

        <template v-slot:header>
          <h2>Guacamole</h2>
        </template>
        <template v-slot:subtitle>
          <p>10 min | mild</p>
        </template>
        <template v-slot:content>
          <p><ul>
            2	Avocado(s), reife <br>
            2	Tomate(n), sehr fein gewürfelte<br>
            ½	Zitrone(n), Saft davon<br>
            2	Knoblauchzehe(n), durchgepresste oder sehr fein gehackte<br>
            1 EL	Naturjoghurt<br>
            Salz und Pfeffer, schwarzer<br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </base-card>
    </div>
  </div>

  <div style="display: grid; grid-template-columns: 1fr 1fr;">
    <div>
      <base-card :image="image3">
        <!-- Individuelle Inhalte für die Slots -->
        <template v-slot:header>
          <h2>Burrito</h2>
        </template>
        <template v-slot:subtitle>
          <p>40 min | mittel</p>
        </template>
        <template v-slot:content>
          <p><ul>
            200 g	Tomaten, geschälte aus der Dose <br>
            125 g	Maiskörner<br>
            1	Paprikaschote(n), rote<br>
            1	Paprikaschote(n), grüne<br>
            2	Zwiebel(n)<br>
            4 EL	Olivenöl<br>
            400 g	Hackfleisch<br>
            Salz und Pfeffer<br>
            1 Prise(n)	Cayennepfeffer<br>
            ½ TL	Kreuzkümmelpulver<br>
            1 EL	Tomatenmark<br>
            1 Prise(n)	Zucker<br>
            6	Weizentortilla(s)<br>
            6 EL	Crème fraîche<br>
            200 g	Käse, geriebener<br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </base-card>
    </div>

    <div>
      <base-card :image="image4">
        <!-- Individuelle Inhalte für die Slots -->

        <template v-slot:header>
          <h2>Taco</h2>
        </template>
        <template v-slot:subtitle>
          <p>30 min | scharf</p>
        </template>
        <template v-slot:content>
          <p><ul>
            1 EL	Öl <br>
            1	Zwiebel(n) <br>
            2	Knoblauchzehe(n) <br>
            500 g	Rinderhackfleisch, mageres <br>
            2 EL	Tomatenmark <br>
            ½ TL	Chilipulver <br>
            1 TL	Paprikapulver <br>
            1 TL	Kreuzkümmelpulver <br>
            1 TL	Korianderpulver <br>
            ½ TL	Oregano <br>
            1 TL	Zucker <br>
            Salz <br>
            12 kleine	Tacos (Schalen) <br>
            4 Blätter	Eisbergsalat (große Blätter), zerkleinerte <br>
            190 g	Cheddarkäse, geriebener <br>
            100 g	Salsa (Tomatensalsa) <br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </base-card>
    </div>


  </div>




</template>

<script>
import BaseCard from '@/components/BaseCard.vue';
import PostCard from "@/components/PostCard.vue";

export default {
  components: {
    PostCard,
    BaseCard,
  },
  data(){
    return{
      image1: 'https://th.bing.com/th/id/OIP.xhjj4KJNq6tCbOudcdSk8wAAAA?rs=1&pid=ImgDetMain',
      image2: 'https://th.bing.com/th/id/OIP.l3eNLqHyOobhRiWeIxLCYgHaLH?rs=1&pid=ImgDetMain',
      image3: 'https://media.istockphoto.com/id/1313361282/de/foto/mexikanische-reis-und-chorizo-wurst-wrap.jpg?s=612x612&w=0&k=20&c=vOw97U-O9MaUshnxJnU-RamCMeCz5lnwGUmSoBrsvH0=',
      image4: 'https://media.istockphoto.com/id/542331706/de/foto/hausgemachte-w%C3%BCrzige-garnelen-tacos.jpg?s=612x612&w=0&k=20&c=x6tuAZWv8VvDadBzsBsFTUQEr4Se1MZ6bWjXwT2hC70=',



    };
  },
};

</script>