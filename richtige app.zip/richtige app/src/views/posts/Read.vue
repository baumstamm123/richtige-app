<script setup>
</script>

<template>
  <h1 style="color: white;">Dein Rezept</h1>
</template>
