<script setup>
</script>

<template>
  <h1>Dein Rezept</h1>
</template>