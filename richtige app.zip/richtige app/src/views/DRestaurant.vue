<template>
  <div style="display: grid; grid-template-columns: 1fr 1fr;">
    <div>
      <BaseCardRestaurant :image="image1">
        <!-- Individuelle Inhalte für die Slots -->
        <template v-slot:header>
          <h2>Restaurant 1</h2>
        </template>
        <template v-slot:subtitle>
          <p>30 min | scharf</p>
        </template>
        <template v-slot:content>
          <p><ul>
            5	Tomaten, geschälte <br>
            2	Paprikaschote(n), rote<br>
            2	Paprikaschote(n), grüne<br>
            3 m.-große	Zwiebel(n)<br>
            2	Chilischote(n)<br>
            1	Zitrone(n), Saft davon<br>
            1 EL, gestr.	Salz<br>
            2 EL	Zucker<br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>

    <div>
      <BaseCardRestaurant :image="image2">
        <!-- Individuelle Inhalte für die Slots -->

        <template v-slot:header>
          <h2>Restaurant 2</h2>
        </template>
        <template v-slot:subtitle>
          <p>30 min | scharf</p>
        </template>
        <template v-slot:content>
          <p><ul>
            2	Avocado(s), reife <br>
            2	Tomate(n), sehr fein gewürfelte<br>
            ½	Zitrone(n), Saft davon<br>
            2	Knoblauchzehe(n), durchgepresste oder sehr fein gehackte<br>
            1 EL	Naturjoghurt<br>
            Salz und Pfeffer, schwarzer<br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>
  </div>

  <div style="display: grid; grid-template-columns: 1fr 1fr;">
    <div>
      <BaseCardRestaurant :image="image3">
        <!-- Individuelle Inhalte für die Slots -->
        <template v-slot:header>
          <h2>Restaurant 3</h2>
        </template>
        <template v-slot:subtitle>
          <p>30 min | scharf</p>
        </template>
        <template v-slot:content>
          <p><ul>
            5	Tomaten, geschälte <br>
            2	Paprikaschote(n), rote<br>
            2	Paprikaschote(n), grüne<br>
            3 m.-große	Zwiebel(n)<br>
            2	Chilischote(n)<br>
            1	Zitrone(n), Saft davon<br>
            1 EL, gestr.	Salz<br>
            2 EL	Zucker<br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>

    <div>
      <BaseCardRestaurant :image="image4">
        <!-- Individuelle Inhalte für die Slots -->

        <template v-slot:header>
          <h2>Salsa</h2>
        </template>
        <template v-slot:subtitle>
          <p>30 min | scharf</p>
        </template>
        <template v-slot:content>
          <p><ul>
            2	Avocado(s), reife <br>
            2	Tomate(n), sehr fein gewürfelte<br>
            ½	Zitrone(n), Saft davon<br>
            2	Knoblauchzehe(n), durchgepresste oder sehr fein gehackte<br>
            1 EL	Naturjoghurt<br>
            Salz und Pfeffer, schwarzer<br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>
  </div>
</template>

<script>
import BaseCardRestaurant from '@/components/BaseCardRestaurant.vue';


export default {
  components: {
    BaseCardRestaurant,
  },
  data(){
    return{
      image1: 'https://media.istockphoto.com/id/1147974792/de/foto/gruppe-gl%C3%BCcklicher-freunde-die-kaffee-und-cappuccino-in-der-vintage-bar-im-freien-trinken.jpg?s=612x612&w=0&k=20&c=7vjHuPeglMHbvMvnui7I9T6UuVdPenb8XhGrmYssrlc=',
      image2: 'https://media.istockphoto.com/id/1002087620/de/foto/l%C3%A4chelnd-beste-freunde-die-spa%C3%9F-in-der-natur-bar-in-deutschland.jpg?s=612x612&w=0&k=20&c=16GR_zoy0lYf5W7NdZiSchXZgxUQi3W1Cx9bpEiIMgM=',
      image3: 'https://media.istockphoto.com/id/1269860279/de/foto/esstisch.jpg?s=612x612&w=0&k=20&c=8HhJjf8tFakJWdUGQC2jcSSRh1MF9LBXLpkwzAKyQVg=',
      image4: 'https://media.istockphoto.com/id/459053342/de/video/sidewalk-cafe-in-berlin-prenzlauer-berg.jpg?s=640x640&k=20&c=dvqFIgV0LCcIg0QKNb4OKHN5OKhydD75nl3hfgzJKGw=',

    };
  },
};

</script>