<template>
  <div style="display: grid; grid-template-columns: 1fr 1fr;">
    <div>
      <BaseCardRestaurant :image="image1">
        <!-- Individuelle Inhalte für die Slots -->
        <template v-slot:header>
          <h2>Restaurant 1</h2>
        </template>
        <template v-slot:subtitle>
          <p>30 min | scharf</p>
        </template>
        <template v-slot:content>
          <p><ul>
            5	Tomaten, geschälte <br>
            2	Paprikaschote(n), rote<br>
            2	Paprikaschote(n), grüne<br>
            3 m.-große	Zwiebel(n)<br>
            2	Chilischote(n)<br>
            1	Zitrone(n), Saft davon<br>
            1 EL, gestr.	Salz<br>
            2 EL	Zucker<br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>

    <div>
      <BaseCardRestaurant :image="image2">
        <!-- Individuelle Inhalte für die Slots -->

        <template v-slot:header>
          <h2>Restaurant 2</h2>
        </template>
        <template v-slot:subtitle>
          <p>30 min | scharf</p>
        </template>
        <template v-slot:content>
          <p><ul>
            2	Avocado(s), reife <br>
            2	Tomate(n), sehr fein gewürfelte<br>
            ½	Zitrone(n), Saft davon<br>
            2	Knoblauchzehe(n), durchgepresste oder sehr fein gehackte<br>
            1 EL	Naturjoghurt<br>
            Salz und Pfeffer, schwarzer<br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>
  </div>

  <div style="display: grid; grid-template-columns: 1fr 1fr;">
    <div>
      <BaseCardRestaurant :image="image3">
        <!-- Individuelle Inhalte für die Slots -->
        <template v-slot:header>
          <h2>Restaurant 3</h2>
        </template>
        <template v-slot:subtitle>
          <p>30 min | scharf</p>
        </template>
        <template v-slot:content>
          <p><ul>
            5	Tomaten, geschälte <br>
            2	Paprikaschote(n), rote<br>
            2	Paprikaschote(n), grüne<br>
            3 m.-große	Zwiebel(n)<br>
            2	Chilischote(n)<br>
            1	Zitrone(n), Saft davon<br>
            1 EL, gestr.	Salz<br>
            2 EL	Zucker<br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>

    <div>
      <BaseCardRestaurant :image="image4">
        <!-- Individuelle Inhalte für die Slots -->

        <template v-slot:header>
          <h2>Salsa</h2>
        </template>
        <template v-slot:subtitle>
          <p>30 min | scharf</p>
        </template>
        <template v-slot:content>
          <p><ul>
            2	Avocado(s), reife <br>
            2	Tomate(n), sehr fein gewürfelte<br>
            ½	Zitrone(n), Saft davon<br>
            2	Knoblauchzehe(n), durchgepresste oder sehr fein gehackte<br>
            1 EL	Naturjoghurt<br>
            Salz und Pfeffer, schwarzer<br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>
  </div>
</template>

<script>
import BaseCardRestaurant from '@/components/BaseCardRestaurant.vue';

export default {
  components: {
    BaseCardRestaurant,
  },
  data(){
    return{
      image1: 'https://media.istockphoto.com/id/468441873/de/foto/italienisches-restaurant.jpg?s=612x612&w=0&k=20&c=bLSW3fPQJMKrqpV0EVBEzCkXTEFdql0DwAVadTg3EIc=',
      image2: 'https://media.istockphoto.com/id/903783156/de/foto/multi-ethnischen-jugendliche-essen-restaurant-rustikale-landschaft-bei-sonnenuntergang.jpg?s=612x612&w=0&k=20&c=q2q9A9aV-ROfQVf9YJrGlv5PS_MeH-Vu2gB4L6Q-PpM=',
      image3: 'https://media.istockphoto.com/id/1192270298/de/foto/menschen-klirren-gl%C3%A4ser-mit-wein-%C3%BCber-tisch-mit-italienischer-pizza.jpg?s=612x612&w=0&k=20&c=0ZPVkSWKC_5bWpbYHlLSDbex4DFS-uQHyxMZ9qtBQe8=',
      image4: 'https://media.istockphoto.com/id/891284194/de/foto/pasta-pizza-und-hausgemachte-verpflegung-in-einem-restaurant-rom.jpg?s=612x612&w=0&k=20&c=ymMjsmkwB-70_79sXyHvGBIpopinSLDuhdHRQYrF75Y=',



    };
  },
};

</script>