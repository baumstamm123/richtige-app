<script setup>
const props = defineProps(['title'])
</script>

<template>
  <VCard
      class="mx-auto"
      max-width="280"
      title="salsa"
      :title="Salsa"
      subtitle="30 min"
      text="Du hast Lust dir einen gemütlichen abend auf dem sofa zu machen und einfaches und schnelles Gericht zu machen. Salsa udn Nachos sind die perfekte Wahl!"
      variant="tonal"
  >
    <template v-slot:prepend>
      <VAvatar >
        <VImg src="https://th.bing.com/th/id/R.d5c34ed14279e230016fd2d63c640140?rik=DOhfjAVA9G%2fdyQ&pid=ImgRaw&r=0" alt="Freddie"/>
      </VAvatar>
    </template>
<!--        <v-badge content="Beaches" color="error"/>-->
    <VDivider/>
    <VCardText>
      consectetur adipiscing elit, sed do eiusmod.
    </VCardText>
  </VCard>
</template>
