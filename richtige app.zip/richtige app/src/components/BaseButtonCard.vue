<!-- BaseButtonCard.vue -->

<template>
  <v-card class="custom-card mx-auto" max-width="500">
    <v-card-actions>
      <router-link :to="routerLink">
        <v-img :src="image"
               class="align-end"
               gradient="to bottom, rgba(0,0,0,.1), rgba(0,0,0,.5)"
               height="270px"
               width="270px"
               cover>

        <v-card-title style="color: #ffffff;">
          {{ title }}
        </v-card-title>

        <v-card-subtitle style="color: #ffffff;">
          {{ subtitle }}
        </v-card-subtitle>

          <v-btn style="color: #ffffff;">
            {{ buttonname }}
          </v-btn>
        </v-img>
      </router-link>
    </v-card-actions>
  </v-card>
</template>

<script>
export default {
  props: {
    image: String,
    title: String,
    subtitle: String,
    buttonname: String,
    routerLink: String,
  },
};
</script>

<style scoped>
.custom-card {
  height: 100%; /* Oder eine andere Höheneinheit, die deinen Anforderungen entspricht */
}
</style>
