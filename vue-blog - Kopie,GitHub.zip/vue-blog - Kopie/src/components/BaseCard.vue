<template>
  <div class="card-container">
    <v-card
        class="mx-auto fixed-card"
        max-width="344"
    >
      <v-img :src="image" height="200px" cover></v-img>

      <v-card-title>
        <slot name="header">Default Header</slot>
      </v-card-title>

      <v-card-subtitle>
        <slot name="subtitle">Default Content</slot>
      </v-card-subtitle>

      <v-card-actions>
        <v-btn color="orange" @click="show = !show">
          <v-icon>{{ show ? 'mdi-chevron-up' : 'mdi-chevron-down' }}</v-icon>
          Zutaten</v-btn>
      </v-card-actions>


      <v-expand-transition>
        <div v-show="show">
          <v-divider></v-divider>

          <v-card-text>
            <slot name="content">Default Content</slot>
          </v-card-text>
          <router-link to="/posts/Read">
            <v-btn color="orange-lighten-2" variant="text" style="margin-bottom: 20px;"> Zum Rezept</v-btn>
          </router-link>
        </div>
      </v-expand-transition>

    </v-card>
  </div>
</template>

<style scoped>

.card-container {
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap; /* bei Bedarf in die nächste Zeile umbrechen */
  padding: 10px;

}

.fixed-card {
  max-width: 150px; /* Setze die gewünschte maximale Breite für die Cards */
  width: 100%; /* Damit die Cards den verfügbaren Platz ausfüllen */
}
.base-card {
  border: 1px solid #ddd;
  border-radius: 1px;
  padding: 16px;
  margin: 16px;
  margin-right: 16px;
  flex: 1;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  max-width: 280px;
}

.card-header {
  font-size: 1.5rem;
  margin-bottom: 8px;
}

.custom-image {
  max-width: 200px; /* Beispiel: Maximale Breite des Bildes */
  max-height: 150px; /* Beispiel: Maximale Höhe des Bildes */
  width: 100%; /* Beispiel: Fülle den verfügbaren Platz aus */
}

.card-content {
  margin-bottom: 8px;
}

.card-footer {
  color: #777;
  font-size: 0.8rem;
}
</style>


<script>
export default {
  props: {
    image: String,
  },
  data: () => ({
    show: false,
  }),
}
</script>