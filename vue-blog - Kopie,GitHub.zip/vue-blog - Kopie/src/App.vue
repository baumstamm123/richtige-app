<script setup>
import BlogIcon from "@/components/icons/IconBlog.vue";
import {ref} from 'vue'

const drawer = ref(true)
</script>

<template>
  <VLayout row wrap rounded rounded-md align-start>
    <VAppBar rounded class="transparent" style="max-height: 500px;">
      <VAppBarNavIcon variant="text" @click.stop="drawer = !drawer"/>
      <v-img src="https://img.fotocommunity.com/der-oktober-in-oberschlesien-e32ecefd-01c4-4e01-ba86-ce08dd23a733.jpg?width=1000" ></v-img>

      <VToolbarTitle>Food Court</VToolbarTitle>


      <VSpacer></VSpacer>
      <VBtn variant="text" icon="mdi-magnify"></VBtn>
      <VBtn variant="text" icon>
        <VIcon>mdi-filter</VIcon>
        <VMenu activator="parent">
          <VList density="compact">
            <VListItem>Italienisch</VListItem>
            <VListItem>Asiatisch</VListItem>
            <VListItem>Mexikanisch</VListItem>
            <VListItem>Deutsch</VListItem>
            <VListItem>fast Food</VListItem>
            <VListItem>Gesund/Vegan</VListItem>
          </VList>
        </VMenu>
      </VBtn>


      <VBtn variant="text" icon>
        <VIcon>mdi-dots-vertical</VIcon>
        <VMenu activator="parent">
          <VList density="compact">
            <VListItem link to="/posts/Profil">Profile </VListItem>
            <VListItem>Settings</VListItem>
          </VList>
        </VMenu>
      </VBtn>
    </VAppBar>




    <VNavigationDrawer mobile-breakpoint="sm" v-model="drawer" class="transparent">

      <v-list>
        <!-- Icon (Vuetify's mdi icon in this case) next to the first list item -->
        <v-list-item :prepend-icon="BlogIcon" link to="/Home">
          <v-list-item-icon>
            <v-icon>{{ BlogIcon }}</v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-list-item-title>Home</v-list-item-title>
          </v-list-item-content>
        </v-list-item>

        <!-- Other list items without icons -->
        <v-list-item class="sub-group" link to="/Home">
          <v-list-item-content>
            <v-list-item-title>1</v-list-item-title>
          </v-list-item-content>
        </v-list-item>

        <v-list-item class="sub-group" link to="/Home">
          <v-list-item-content>
            <v-list-item-title>2</v-list-item-title>
          </v-list-item-content>
        </v-list-item>



        <VListItem prepend-icon="mdi-shape" link to="/Restaurant">
          Restaurant
        </VListItem>
        <VListItem prepend-icon="mdi-account-multiple" link to="/Rezept">
          Rezept
        </VListItem>

      </V-list>
    </VNavigationDrawer>

    <VMain>
      <RouterView></RouterView>
    </VMain>
    <VBtn link to="/posts/create"
          variant="elevated" icon="mdi-plus" color="indigo-darken-4"
          position="fixed" size="large" style="bottom:5em; right:3em">
    </VBtn>


  </VLayout>
</template>
<style>
.sub-group {
  margin-left: 40px; /* Hier kannst du die gewünschte Einrückung in Pixeln anpassen */
}
</style>

