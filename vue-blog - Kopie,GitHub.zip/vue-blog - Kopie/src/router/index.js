import Home from "@/views/posts/Home.vue";
import Rezept from "@/views/Rezept.vue";
import Restaurant from "@/views/Restaurant.vue";
import Read from "@/views/posts/Read.vue";
import Create from "@/views/posts/Create.vue";
import MRezepte from "@/views/MRezepte.vue";
import IRezepte from "@/views/IRezepte.vue";
import DRezepte from "@/views/DRezepte.vue";
import MRestaurant from "@/views/MRestaurant.vue";
import IRestaurant from "@/views/IRestaurant.vue";
import DRestaurant from "@/views/DRestaurant.vue";
import Profil from "@/views/posts/Profil.vue";
import IndRestaurant from "@/views/IndRestaurant.vue";
import IndRezepte from "@/views/IndRezepte.vue";





const routes = [
  {path: '/', component: Home},
  {path: '/posts', component: Home},
  {path: '/posts/:id', component: Read},
  {path: '/posts/create', component: Create},
  {path: '/posts/update', component: Home},
  {path: '/posts/save', component: Home},
  {path: '/posts/delete', component: Home},
  {path: '/Restaurant', component: Restaurant},
  {path: '/Rezept', component: Rezept},
  {path: '/posts/Home', component: Home},
  {path: '/posts/Read', component: Read},
  {path: '/MRezepte', component: MRezepte},
  {path: '/IRezepte', component: IRezepte},
  {path: '/DRezepte', component: DRezepte},
  {path: '/MRestaurant', component: MRestaurant},
  {path: '/IRestaurant', component: IRestaurant},
  {path: '/DRestaurant', component: DRestaurant},
  {path: '/posts/Profil', component: Profil},
  {path: '/IndRestaurant', component: IndRestaurant},
  {path: '/IndRezepte', component: IndRezepte},











];
export default routes;
