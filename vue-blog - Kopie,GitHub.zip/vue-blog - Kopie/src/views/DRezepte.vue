<template>
  <div style="display: grid; grid-template-columns: 1fr 1fr;">
    <div>
      <base-card :image="image1">
        <!-- Individuelle Inhalte für die Slots -->
        <template v-slot:header>
          <h2>Kartoffelsuppe</h2>
        </template>
        <template v-slot:subtitle>
          <p>40 min | mild</p>
        </template>
        <template v-slot:content>
          <p><ul>
            1 kg	Kartoffel(n)<br>
            4	Karotte(n)<br>
            1 Bund	Suppengrün<br>
            2 EL	Gemüsebrühepulver<br>
            3 Paar	Wiener Würstchen<br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </base-card>
    </div>

    <div>
      <base-card :image="image2">
        <!-- Individuelle Inhalte für die Slots -->

        <template v-slot:header>
          <h2>Wiener Schnitzel</h2>
        </template>
        <template v-slot:subtitle>
          <p>40 min | mild</p>
        </template>
        <template v-slot:content>
          <p><ul>
            2 dünne	Kalbsschnitzel<br>
            10 EL	Semmelbrösel oder Paniermehl (schmeckt unterschiedlich)<br>
            10 EL	Mehl<br>
            2	Eigelb<br>
            1	Ei(er)<br>
            1 Liter	Sonnenblumenöl<br>
            1 TL, gehäuft	Paprikapulver, rosenscharfes<br>
            1 TL, gestr.	Pfeffer, weißer<br>
            1 TL, gestr.	Salz<br>
            1 Prise(n)	Zucker<br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </base-card>
    </div>
  </div>

  <div style="display: grid; grid-template-columns: 1fr 1fr;">
    <div>
      <base-card :image="image3">
        <!-- Individuelle Inhalte für die Slots -->
        <template v-slot:header>
          <h2>Käsespätzle</h2>
        </template>
        <template v-slot:subtitle>
          <p>20 min | mild</p>
        </template>
        <template v-slot:content>
          <p><ul>
            1	Zwiebel(n), gewürfelte<br>
            Butter<br>
            400 ml	Sahne<br>
            ½ Bund	Petersilie, gehackte<br>
            Salz und Pfeffer<br>
            200 g	Emmentaler, geriebener<br>
            1 kg	Spätzle, frische, aus dem Kühlregal<br>
            Fett für die Form<br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </base-card>
    </div>

    <div>
      <base-card :image="image4">
        <!-- Individuelle Inhalte für die Slots -->

        <template v-slot:header>
          <h2>Kartoffelgratin</h2>
        </template>
        <template v-slot:subtitle>
          <p>30 min | scharf</p>
        </template>
        <template v-slot:content>
          <p><ul>
            500 g	Kartoffeln, vorwiegend festkochende<br>
            125 ml	Milch<br>
            125 ml	süße Sahne<br>
            1	Knoblauchzehe(n)<br>
            Salz und Pfeffer<br>
            Rosmarin<br>
            Butter für die Form<br>
            3 EL	Käse, frisch geriebener z.B. Parmesan oder Pecorino<br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </base-card>
    </div>


  </div>




</template>

<script>
import BaseCard from '@/components/BaseCard.vue';
import PostCard from "@/components/PostCard.vue";

export default {
  components: {
    PostCard,
    BaseCard,
  },
  data(){
    return{
      image1: 'https://media.istockphoto.com/id/1178323067/de/foto/kartoffelsuppe.jpg?s=612x612&w=0&k=20&c=AjnLYzmz-3H97yedeZ5-lglW9OiBLkVdlpRbq6g9BiE=',
      image2: 'https://media.istockphoto.com/id/486565658/de/foto/hausgemachte-paniertes-deutschen-weiner-schnitzel.jpg?s=612x612&w=0&k=20&c=Zrg4mjzV1EDYtNc5Yv7LmL8ieyq9wI2a3jwGpcJiZTc=',
      image3: 'https://media.istockphoto.com/id/482066096/de/foto/kasta-tomb.jpg?s=612x612&w=0&k=20&c=7zHk7XAt02BgJM7t7-79hOFwgB1YmclU_24g4iyNLOg=',
      image4: 'https://media.istockphoto.com/id/1165297537/de/foto/kartoffelgratin.jpg?s=612x612&w=0&k=20&c=h25G1l7Q94MiA1k73lRGEgb78lhU0WeJmCdDkttwS5w=',


    };
  },
};

</script>