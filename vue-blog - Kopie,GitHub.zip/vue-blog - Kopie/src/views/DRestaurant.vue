<template>
  <div style="display: grid; grid-template-columns: 1fr 1fr;">
    <div>
      <BaseCardRestaurant :image="image1"
                          :rating="4.2"
                          :reviews="160"
                          dollar="$$$"
                          cuisine="Indisch"
                          category="Bar">
        <!-- Individuelle Inhalte für die Slots -->
        <template v-slot:header>
          <h2>Restaurant 1</h2>
        </template>
        <template v-slot:subtitle>
          <p>Adresse 1</p>
        </template>
        <template v-slot:content>
          <p>Kleine Gerichte, Salate und Sandwiches in einem intimen Rahmen mit 12 Innenplätzen und Sitzplätzen auf der Terrasse.</p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>

    <div>
      <BaseCardRestaurant :image="image2"
                          :rating="3.2"
                          :reviews="80"
                          dollar="$"
                          cuisine="Indisch"
                          category="Restaurant">
        <!-- Individuelle Inhalte für die Slots -->

        <template v-slot:header>
          <h2>Restaurant 2</h2>
        </template>
        <template v-slot:subtitle>
          <p>Adresse 2</p>
        </template>
        <template v-slot:content>
          <p>Kleine Gerichte, Salate und Sandwiches in einem intimen Rahmen mit 12 Innenplätzen und Sitzplätzen auf der Terrasse.</p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>
  </div>

  <div style="display: grid; grid-template-columns: 1fr 1fr;">
    <div>
      <BaseCardRestaurant :image="image3"
                          :rating="4.7"
                          :reviews="130"
                          dollar="$"
                          cuisine="Indisch"
                          category="Restaurant">
        <!-- Individuelle Inhalte für die Slots -->
        <template v-slot:header>
          <h2>Restaurant 3</h2>
        </template>
        <template v-slot:subtitle>
          <p>Adresse 3</p>
        </template>
        <template v-slot:content>
          <p>Kleine Gerichte, Salate und Sandwiches in einem intimen Rahmen mit 12 Innenplätzen und Sitzplätzen auf der Terrasse.</p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>

    <div>
      <BaseCardRestaurant :image="image4"
                          :rating="5.0"
                          :reviews="150"
                          dollar="$$"
                          cuisine="Indisch"
                          category="Restaurant">
        <!-- Individuelle Inhalte für die Slots -->

        <template v-slot:header>
          <h2>Restaurant 4</h2>
        </template>
        <template v-slot:subtitle>
          <p>Adresse 4</p>
        </template>
        <template v-slot:content>
          <p>Kleine Gerichte, Salate und Sandwiches in einem intimen Rahmen mit 12 Innenplätzen und Sitzplätzen auf der Terrasse.</p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>
  </div>
</template>

<script>
import BaseCardRestaurant from '@/components/BaseCardRestaurant.vue';


export default {
  components: {
    BaseCardRestaurant,
  },
  data(){
    return{
      image1: 'https://media.istockphoto.com/id/1147974792/de/foto/gruppe-gl%C3%BCcklicher-freunde-die-kaffee-und-cappuccino-in-der-vintage-bar-im-freien-trinken.jpg?s=612x612&w=0&k=20&c=7vjHuPeglMHbvMvnui7I9T6UuVdPenb8XhGrmYssrlc=',
      image2: 'https://media.istockphoto.com/id/1002087620/de/foto/l%C3%A4chelnd-beste-freunde-die-spa%C3%9F-in-der-natur-bar-in-deutschland.jpg?s=612x612&w=0&k=20&c=16GR_zoy0lYf5W7NdZiSchXZgxUQi3W1Cx9bpEiIMgM=',
      image3: 'https://media.istockphoto.com/id/1269860279/de/foto/esstisch.jpg?s=612x612&w=0&k=20&c=8HhJjf8tFakJWdUGQC2jcSSRh1MF9LBXLpkwzAKyQVg=',
      image4: 'https://media.istockphoto.com/id/459053342/de/video/sidewalk-cafe-in-berlin-prenzlauer-berg.jpg?s=640x640&k=20&c=dvqFIgV0LCcIg0QKNb4OKHN5OKhydD75nl3hfgzJKGw=',

    };
  },
};

</script>