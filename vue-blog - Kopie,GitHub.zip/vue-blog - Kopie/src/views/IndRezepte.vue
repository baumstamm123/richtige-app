<template>
  <div style="display: grid; grid-template-columns: 1fr 1fr;">
    <div>
      <base-card :image="image1">
        <!-- Individuelle Inhalte für die Slots -->
        <template v-slot:header>
          <h2>Chicken Masala</h2>
        </template>
        <template v-slot:subtitle>
          <p>45 min | mittel</p>
        </template>
        <template v-slot:content>
          <p><ul>
            700 g	Putenfleisch<br>
            1	Zwiebel(n)<br>
            5	Knoblauchzehe(n)<br>
            125 g	Butter<br>
            3 TL	Koriander<br>
            3 TL, gehäuft	Currypulver<br>
            1 TL, gehäuft	Paprikapulver<br>
            1	Chilischote(n)<br>
            1 TL	Gemüsebrühepulver<br>
            1 TL, gehäuft	Salz<br>
            1 TL	Pfeffer, am besten aus der Mühle<br>
            2 Dose/n	Tomaten, stückige, je ca. 400 g<br>
            ½ Dose	Kokosmilch, ca. 200 ml<br>
            1 Handvoll	Petersilie, frisch<br>
            ½ TL	Kurkuma<br>
            1	Nelke(n)<br>
            4 EL	Tomatenmark<br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </base-card>
    </div>

    <div>
      <base-card :image="image2">
        <!-- Individuelle Inhalte für die Slots -->

        <template v-slot:header>
          <h2>Palak Paneer</h2>
        </template>
        <template v-slot:subtitle>
          <p>45 min | mittel</p>
        </template>
        <template v-slot:content>
          <p><ul>
            2 Liter	Milch <br>
            6 EL	Zitronensaft oder Essig<br>
            4 EL	Pflanzenöl<br>
            200 g	Zwiebel(n), fein geschnitten<br>
            1 TL	Kreuzkümmel, ganz<br>
            4	Tomate(n), fein gehackt<br>
            ½ TL	Chilipulver<br>
            ½ TL	Kurkumapulver<br>
            1 ½ TL	Salz<br>
            350 g	Spinat, fein gehackt<br>
            50 ml	Sahne<br>
            ½ TL	Korianderpulver<br>
            ½ TL	Garam Masala<br>
            2 cm	Ingwerwurzel, frischer, in Streifen geschnitten<br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </base-card>
    </div>
  </div>

  <div style="display: grid; grid-template-columns: 1fr 1fr;">
    <div>
      <base-card :image="image3">
        <!-- Individuelle Inhalte für die Slots -->
        <template v-slot:header>
          <h2>Rotes Linsen Dal</h2>
        </template>
        <template v-slot:subtitle>
          <p>40 min | mild</p>
        </template>
        <template v-slot:content>
          <p><ul>
            1 EL	Kokosöl<br>
            2	Zwiebel(n), gewürfelt<br>
            n. B.	Knoblauchzehe(n), gepresst<br>
            2 TL	Ingwer, gerieben<br>
            1 TL	Kurkuma<br>
            ½ TL	Kreuzkümmelpulver<br>
            1 TL	Paprikapulver<br>
            1 EL	Currypulver<br>
            300 g	Linsen, rote<br>
            800 ml	Gemüsebrühe<br>
            250 ml	Kokosmilch<br>
            250 ml	Tomaten, passierte oder gehackte<br>
            etwas	Salz und Pfeffer<br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </base-card>
    </div>

    <div>
      <base-card :image="image4">
        <!-- Individuelle Inhalte für die Slots -->

        <template v-slot:header>
          <h2>Gemüse-Curry</h2>
        </template>
        <template v-slot:subtitle>
          <p>30 min | scharf</p>
        </template>
        <template v-slot:content>
          <p><ul>
            500 g	Kartoffel(n)<br>
            250 g	Karotte(n)<br>
            500 g	Zucchini<br>
            250 g	Aubergine(n)<br>
            2	Banane(n)<br>
            2	Äpfel<br>
            10	Knoblauchzehe(n)<br>
            500 ml	Kokosmilch<br>
            500 ml	Gemüsebouillon<br>
            1 EL	Kokosfett<br>
            2 EL	Currypulver, indisch<br>
            1 EL	Kurkuma<br>
            1 EL	Garam Masala<br>
            1	Zwiebel(n)<br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </base-card>
    </div>


  </div>




</template>

<script>
import BaseCard from '@/components/BaseCard.vue';
import PostCard from "@/components/PostCard.vue";

export default {
  components: {
    PostCard,
    BaseCard,
  },
  data(){
    return{
      image1: 'https://media.istockphoto.com/id/1227594550/de/foto/h%C3%BChnercurry-cremige-h%C3%BChnerbutter.jpg?s=612x612&w=0&k=20&c=24rSqQw4viE_7v4lidl-CWZzusrzAykmup3xEz7vuBo=',
      image2: 'https://media.istockphoto.com/id/497833552/de/foto/palak-paneer-und-nan-brot.jpg?s=612x612&w=0&k=20&c=uogF3PtfZuphIOf13SCL1wo9MMmRrMDHiVDAEUFVvL8=',
      image3: 'https://media.istockphoto.com/id/1130228942/de/foto/indische-dal-traditionelle-indische-suppe-linsen-w%C3%BCrzige-indische-dhal-curry-in-sch%C3%BCssel.jpg?s=612x612&w=0&k=20&c=mP9FgDDRfjh-0oZ_3sEKAXxjSbMvFk_whlqi7gejEeA=',
      image4: 'https://media.istockphoto.com/id/1178768522/de/foto/traditionelle-dicke-s%C3%BC%C3%9Fkartoffelsuppe-mit-linsen-aus-n%C3%A4chster-n%C3%A4he-in-einer-sch%C3%BCssel-auf-dem.jpg?s=612x612&w=0&k=20&c=eQ-cWSXeVtR5pP8Cl5e23YS0-OULJH5yVTDY8GwCegE=',


    };
  },
};

</script>