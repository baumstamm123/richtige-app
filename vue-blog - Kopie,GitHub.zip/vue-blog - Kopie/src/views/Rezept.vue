<template>
  <h1 style="color: white;">Worauf hast du heute Lust?</h1>
  <h2 style="color: white;">Wähle die kulinarische Richtung!</h2>
  <v-container fluid>
    <v-row align="center" justify="center">
      <v-col v-for="card in cards" :key="card.title" cols="12" md="6" lg="4">
        <base-button-card
            :image="card.image"
            :title="card.title"
            :subtitle="card.subtitle"
            :buttonname="card.buttonname"
            :router-link="card.routerLink"
        />
      </v-col>
    </v-row>
  </v-container>

</template>

<script>
import BaseButtonCard from "@/components/BaseButtonCard.vue";

export default {
  components: {
    BaseButtonCard,
  },
  data() {
    return {
      cards: [
        {
          image: "https://media.istockphoto.com/id/1341928493/de/foto/mexikanische-tacos-flat-lay-komposition-mit-schweinefleisch-carnitas-cochinita-pibil-zwiebel.jpg?s=612x612&w=0&k=20&c=kPwax3oJ-6Unc96EqoecsESR6u33EJEVNMYX3HRsTUE=",
          title: "Mexikanische Rezepte",
          subtitle: "Alles rund um Tacos und Salsa",
          buttonname: "Zu den Rezepten",
          routerLink: "/MRezepte",
          flex: 12,
        },
        {
          image: "https://media.istockphoto.com/id/488960908/de/foto/selbstgemachte-pasta.jpg?s=612x612&w=0&k=20&c=b-fDtcm1AI4s9zkQ9RVbB-FYzRlkiyTz9KYTUb626f4=",
          title: "Italiensiche Rezepte",
          subtitle: "Pizza, Pasta und vieles mehr",
          buttonname: "Zu den Rezepten",
          routerLink: "/IRezepte",
          flex: 12,
        },
        {
          image: "https://media.istockphoto.com/id/508212832/de/foto/hausgemachte-bratw%C3%BCrstchen-mit-kartoffelp%C3%BCree-bangers-und-maische.jpg?s=612x612&w=0&k=20&c=IR2Xk9ZuNK4HZoAZv4Gv6rW1vgpTugMBx1bsI8DSVA0=",
          title: "Deutsche Rezepte",
          subtitle: "Grundsätzliches alles mit Kartoffel",
          buttonname: "Zu den Rezepten",
          routerLink: "/DRezepte",
          flex: 12,
        },
        {
          image: "https://img.freepik.com/fotos-kostenlos/draufsichtsortiment-verschiedener-pakistanischer-leckereien_23-2148821568.jpg?size=626&ext=jpg&ga=GA1.1.1226583607.1701602956&semt=ais",
          title: "Indische Rezepte",
          subtitle: "Immer würzig",
          buttonname: "Zu den Rezepten",
          routerLink: "/IndRezepte",
          flex: 12,
        },

        // Weitere Cards mit individuellen Werten
      ],
    };
  },
};
</script>
