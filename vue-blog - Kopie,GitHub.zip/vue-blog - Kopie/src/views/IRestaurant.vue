<template>
  <div style="display: grid; grid-template-columns: 1fr 1fr;">
    <div>
      <BaseCardRestaurant :image="image1"
                          :rating="3.2"
                          :reviews="460"
                          dollar="$$"
                          cuisine="Italienisch"
                          category="Bar">
        <!-- Individuelle Inhalte für die Slots -->
        <template v-slot:header>
          <h2>Restaurant 1</h2>
        </template>
        <template v-slot:subtitle>
          <p>Adresse 1</p>
        </template>
        <template v-slot:content>
          <p>Kleine Gerichte, Salate und Sandwiches in einem intimen Rahmen mit 12 Innenplätzen und Sitzplätzen auf der Terrasse.</p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>

    <div>
      <BaseCardRestaurant :image="image2"
                          :rating="4.2"
                          :reviews="60"
                          dollar="$"
                          cuisine="Italienisch"
                          category="Restaurant">
        <!-- Individuelle Inhalte für die Slots -->

        <template v-slot:header>
          <h2>Restaurant 2</h2>
        </template>
        <template v-slot:subtitle>
          <p>Adresse 2</p>
        </template>
        <template v-slot:content>
          <p>Kleine Gerichte, Salate und Sandwiches in einem intimen Rahmen mit 12 Innenplätzen und Sitzplätzen auf der Terrasse.</p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>
  </div>

  <div style="display: grid; grid-template-columns: 1fr 1fr;">
    <div>
      <BaseCardRestaurant :image="image3"
                          :rating="4.0"
                          :reviews="230"
                          dollar="$"
                          cuisine="Italienisch"
                          category="Restaurant">
        <!-- Individuelle Inhalte für die Slots -->
        <template v-slot:header>
          <h2>Restaurant 3</h2>
        </template>
        <template v-slot:subtitle>
          <p>Adresse 3</p>
        </template>
        <template v-slot:content>
          <p>Kleine Gerichte, Salate und Sandwiches in einem intimen Rahmen mit 12 Innenplätzen und Sitzplätzen auf der Terrasse.</p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>

    <div>
      <BaseCardRestaurant :image="image4"
                          :rating="3.2"
                          :reviews="90"
                          dollar="$$"
                          cuisine="Italienisch"
                          category="Restaurant">
        <!-- Individuelle Inhalte für die Slots -->

        <template v-slot:header>
          <h2>Restaurant 4</h2>
        </template>
        <template v-slot:subtitle>
          <p>Adresse 4</p>
        </template>
        <template v-slot:content>
          <p>Kleine Gerichte, Salate und Sandwiches in einem intimen Rahmen mit 12 Innenplätzen und Sitzplätzen auf der Terrasse.</p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>
  </div>
</template>

<script>
import BaseCardRestaurant from '@/components/BaseCardRestaurant.vue';

export default {
  components: {
    BaseCardRestaurant,
  },
  data(){
    return{
      image1: 'https://media.istockphoto.com/id/468441873/de/foto/italienisches-restaurant.jpg?s=612x612&w=0&k=20&c=bLSW3fPQJMKrqpV0EVBEzCkXTEFdql0DwAVadTg3EIc=',
      image2: 'https://media.istockphoto.com/id/903783156/de/foto/multi-ethnischen-jugendliche-essen-restaurant-rustikale-landschaft-bei-sonnenuntergang.jpg?s=612x612&w=0&k=20&c=q2q9A9aV-ROfQVf9YJrGlv5PS_MeH-Vu2gB4L6Q-PpM=',
      image3: 'https://media.istockphoto.com/id/1192270298/de/foto/menschen-klirren-gl%C3%A4ser-mit-wein-%C3%BCber-tisch-mit-italienischer-pizza.jpg?s=612x612&w=0&k=20&c=0ZPVkSWKC_5bWpbYHlLSDbex4DFS-uQHyxMZ9qtBQe8=',
      image4: 'https://media.istockphoto.com/id/891284194/de/foto/pasta-pizza-und-hausgemachte-verpflegung-in-einem-restaurant-rom.jpg?s=612x612&w=0&k=20&c=ymMjsmkwB-70_79sXyHvGBIpopinSLDuhdHRQYrF75Y=',



    };
  },
};

</script>