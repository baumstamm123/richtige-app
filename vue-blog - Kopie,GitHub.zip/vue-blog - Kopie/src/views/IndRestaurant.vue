<template>
  <div style="display: grid; grid-template-columns: 1fr 1fr;">
    <div>
      <BaseCardRestaurant :image="image1"
                          :rating="4.2"
                          :reviews="160"
                          dollar="$$$"
                          cuisine="Deutsch"
                          category="Bar">
        <!-- Individuelle Inhalte für die Slots -->
        <template v-slot:header>
          <h2>Restaurant 1</h2>
        </template>
        <template v-slot:subtitle>
          <p>Adresse 1</p>
        </template>
        <template v-slot:content>
          <p>Kleine Gerichte, Salate und Sandwiches in einem intimen Rahmen mit 12 Innenplätzen und Sitzplätzen auf der Terrasse.</p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>

    <div>
      <BaseCardRestaurant :image="image2"
                          :rating="3.2"
                          :reviews="80"
                          dollar="$"
                          cuisine="Deutsch"
                          category="Restaurant">
        <!-- Individuelle Inhalte für die Slots -->

        <template v-slot:header>
          <h2>Restaurant 2</h2>
        </template>
        <template v-slot:subtitle>
          <p>Adresse 2</p>
        </template>
        <template v-slot:content>
          <p>Kleine Gerichte, Salate und Sandwiches in einem intimen Rahmen mit 12 Innenplätzen und Sitzplätzen auf der Terrasse.</p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>
  </div>

  <div style="display: grid; grid-template-columns: 1fr 1fr;">
    <div>
      <BaseCardRestaurant :image="image3"
                          :rating="4.7"
                          :reviews="130"
                          dollar="$"
                          cuisine="Deutsch"
                          category="Restaurant">
        <!-- Individuelle Inhalte für die Slots -->
        <template v-slot:header>
          <h2>Restaurant 3</h2>
        </template>
        <template v-slot:subtitle>
          <p>Adresse 3</p>
        </template>
        <template v-slot:content>
          <p>Kleine Gerichte, Salate und Sandwiches in einem intimen Rahmen mit 12 Innenplätzen und Sitzplätzen auf der Terrasse.</p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>

    <div>
      <BaseCardRestaurant :image="image4"
                          :rating="5.0"
                          :reviews="150"
                          dollar="$$"
                          cuisine="Deutsch"
                          category="Restaurant">
        <!-- Individuelle Inhalte für die Slots -->

        <template v-slot:header>
          <h2>Restaurant 4</h2>
        </template>
        <template v-slot:subtitle>
          <p>Adresse 4</p>
        </template>
        <template v-slot:content>
          <p>Kleine Gerichte, Salate und Sandwiches in einem intimen Rahmen mit 12 Innenplätzen und Sitzplätzen auf der Terrasse.</p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>
  </div>
</template>

<script>
import BaseCardRestaurant from '@/components/BaseCardRestaurant.vue';


export default {
  components: {
    BaseCardRestaurant,
  },
  data(){
    return{
      image1: 'https://media.istockphoto.com/id/505964202/de/foto/freundinnen-genie%C3%9Fen-sie-den-abend-in-der-cocktail-bar.jpg?s=612x612&w=0&k=20&c=ADWVUPeUiIxUHTmezg_axmefX_m8aeku5MZavMLivi8=',
      image2: 'https://media.istockphoto.com/id/608568012/de/foto/indische-sat-essen-k%C3%BCche-zusammengeh%C3%B6rigkeit-konzept.jpg?s=612x612&w=0&k=20&c=cSS1-Y9Jz2Y6m7wLyCySQLtgqYSnrDY0mRr8BHzvcOg=',
      image3: 'https://media.istockphoto.com/id/1319278000/de/foto/konzentrieren-sie-sich-auf-front-boy-gruppe-von-freunden-spa%C3%9F-und-lachen-w%C3%A4hrend-zusammen.jpg?s=612x612&w=0&k=20&c=LJCzKSBShDj_sRjs7Awc87ZrpZZd085vkH4hcuxg7_c=',
      image4: 'https://media.istockphoto.com/id/816774502/de/foto/indische-k%C3%BCche.jpg?s=612x612&w=0&k=20&c=wVT5nlQMg_PDWxo-O2Fo43mSKTHGKn0P1nelqGaunek=',

    };
  },
};

</script>