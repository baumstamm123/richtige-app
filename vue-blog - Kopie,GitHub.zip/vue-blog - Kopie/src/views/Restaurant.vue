<template>
  <h1 style="color: white;">Worauf hast du heute Lust?</h1>
  <h2 style="color: white;">Wähle die kulinarische Richtung!</h2>
  <v-container fluid>
    <v-row align="center" justify="center">
      <v-col v-for="card in cards" :key="card.title" cols="12" md="6" lg="4">
        <base-button-card
            :image="card.image"
            :title="card.title"
            :subtitle="card.subtitle"
            :buttonname="card.buttonname"
            :router-link="card.routerLink"
        />
      </v-col>
    </v-row>
  </v-container>

</template>

<script>
import BaseButtonCard from "@/components/BaseButtonCard.vue";

export default {
  components: {
    BaseButtonCard,
  },
  data() {
    return {
      cards: [
        {
          image: "https://media.istockphoto.com/id/906045688/de/foto/traditionelle-mexikanische-restaurant-einstellung.jpg?s=612x612&w=0&k=20&c=q5DdG5ij1xH1OyRB9GrAmydhydP2O7dY8JWUGLLf8_M=",
          title: "Mexikanische Restaurant",
          subtitle: "Alles rund um Tacos und Salsa",
          buttonname: "Zu den Details",
          routerLink: "/MRestaurant",
          flex: 12,
        },
        {
          image: "https://media.istockphoto.com/id/453203585/de/foto/trattoria-im-freien-in-einem-malerischen-dorf-in-der-toskana-italien.jpg?s=612x612&w=0&k=20&c=eiPpvMPuygmG4A29qcSmz5NUvygccBgs7XMbiHGhIvM=",
          title: "Italienisches Restaurant",
          subtitle: "Pizza, Pasta und vieles mehr!",
          buttonname: "Zu den Details",
          routerLink: "/IRestaurant",
          flex: 12,
        },
        {
          image: "https://media.istockphoto.com/id/962573364/de/foto/gruppe-der-happy-friends-trinken-und-toasten-bier-brauerei-bar-restaurant-konzept-der.jpg?s=612x612&w=0&k=20&c=sd8tsKEvMxCxiv7aqlLfCRSC9KCI3hJhjvBWt1LaF1A=",
          title: "Deutsches Restaurant",
          subtitle: "Hopfen und Malz, Gott erhals!!",
          buttonname: "Zu den Details",
          routerLink: "/DRestaurant",
          flex: 12,
        },
        {
          image: "https://media.istockphoto.com/id/154947865/de/foto/traditionelle-nepali-restaurant.jpg?s=612x612&w=0&k=20&c=SOc2W9JnxAjkaX1Qln1XgjcURo5-c1SWLpy-gCrzOsc=",
          title: "Indisches Restaurant",
          subtitle: "Immer würzig!!",
          buttonname: "Zu den Details",
          routerLink: "/IndRestaurant",
          flex: 12,
        },

        // Weitere Cards mit individuellen Werten
      ],
    };
  },
};
</script>
