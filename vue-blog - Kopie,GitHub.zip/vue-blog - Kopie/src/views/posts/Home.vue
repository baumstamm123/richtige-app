<template>
  <h1>Worauf hast du heute Lust?</h1>
  <h2>Wähle die kulinarische Richtung!</h2>
  <v-container fluid>
    <v-row align="center" justify="center">
      <v-col v-for="card in cards" :key="card.title">
        <base-button-card
            :image="card.image"
            :title="card.title"
            :subtitle="card.subtitle"
            :router-link="card.routerLink"
        />
      </v-col>
    </v-row>
  </v-container>

</template>

<script>
import BaseButtonCard from "@/components/BaseButtonCard.vue";

export default {
  components: {
    BaseButtonCard,
  },
  data() {
    return {
      cards: [
        {
          image: "https://i.pinimg.com/originals/de/78/0e/de780e0b83a13a351fb2cde8c2cd6010.jpg",
          title: "Mexikanische Rezepte",
          subtitle: "Alles rund um Tacos und Salsa",
          routerLink: "/MRezepte",
          flex: 12,
        },
        {
          image: "https://i.pinimg.com/originals/de/78/0e/de780e0b83a13a351fb2cde8c2cd6010.jpg",
          title: "Mexikanische Rezepte",
          subtitle: "Alles rund um Tacos und Salsa",
          routerLink: "/MRezepte",
          flex: 12,
        },
        // Weitere Cards mit individuellen Werten
      ],
    };
  },
};
</script>
