<script setup>
</script>

<template>
  <h1 style="color: white;">Letzte Seite. Hier ist Schluss!!!</h1>
</template>
