<script setup>
</script>

<template>
  <h1>Create Post</h1>
</template>
