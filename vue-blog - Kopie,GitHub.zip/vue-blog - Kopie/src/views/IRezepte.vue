<template>
  <div style="display: grid; grid-template-columns: 1fr 1fr;">
    <div>
      <base-card :image="image1">
        <!-- Individuelle Inhalte für die Slots -->
        <template v-slot:header>
          <h2>Bolognese</h2>
        </template>
        <template v-slot:subtitle>
          <p>30 min | mild</p>
        </template>
        <template v-slot:content>
          <p><ul>
            250 g	Rinderhackfleisch<br>
            1 Dose	Pizzatomaten<br>
            1	Knoblauchzehe(n)<br>
            1	Zwiebel(n)<br>
            etwas	Tomatenmark<br>
            etwas	Rotwein<br>
            1 TL	Oregano, gerebelt<br>
            1 TL	Majoran, gerebelt<br>
            1 TL	Basilikum, gerebelt<br>
            1 TL	Paprikapulver<br>
            Brühe, gekörnte<br>
            Salz und Pfeffer<br>
            1 EL	Olivenöl<br>
            1 TL	Zucker<br>
            200 g	Spaghetti<br>
            Parmesan<br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </base-card>
    </div>

    <div>
      <base-card :image="image2">
        <!-- Individuelle Inhalte für die Slots -->

        <template v-slot:header>
          <h2>Bruschetta</h2>
        </template>
        <template v-slot:subtitle>
          <p>15 min | mittel</p>
        </template>
        <template v-slot:content>
          <p><ul>
            10 große	Tomate(n), frische <br>
            1	Zwiebel(n)<br>
            1 Zehe/n	Knoblauch, klein gehackt<br>
            1 großes	Baguette(s) oder Ciabatta<br>
            etwas	Parmesan<br>
            1 Bund	Basilikum, klein gehackt<br>
            etwas	Olivenöl<br>
            etwas	Oregano<br>
            50 ml	Balsamico<br>
            50 ml	Rotwein<br>
            50 ml	Orangensaft<br>
            2 EL	Honig<br>
            Salz und Pfeffer<br>
            1 Prise(n)	Pimentpulver<br>
            evtl.	Chilipulver<br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </base-card>
    </div>
  </div>

  <div style="display: grid; grid-template-columns: 1fr 1fr;">
    <div>
      <base-card :image="image3">
        <!-- Individuelle Inhalte für die Slots -->
        <template v-slot:header>
          <h2>Risotto</h2>
        </template>
        <template v-slot:subtitle>
          <p>30 min | mild</p>
        </template>
        <template v-slot:content>
          <p><ul>
            1 Tasse/n	Reis, (Risottoreis) oder Rundkornreis - auf keinen Fall Langkornreis<br>
            1 kleine	Zwiebel(n)<br>
            3 EL	Olivenöl<br>
            1 EL	Butter<br>
            1 Würfel	Brühe (Fleisch-, Huhn- oder Gemüsebrühe)<br>
            1 Handvoll	Parmesan, geraspelten, wenn möglich echten Grana, Parmigiano, kann aber auch Emmentaler sein<br>
            250 ml	Wein, weiß<br>
            1 Handvoll	Steinpilze, getrocknete<br>
            3 EL	Schlagsahne<br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </base-card>
    </div>

    <div>
      <base-card :image="image4">
        <!-- Individuelle Inhalte für die Slots -->

        <template v-slot:header>
          <h2>Lasagne</h2>
        </template>
        <template v-slot:subtitle>
          <p>50min | mittel</p>
        </template>
        <template v-slot:content>
          <p><ul>
            600 g	Hackfleisch<br>
            2	Zwiebel(n)<br>
            1 EL	Tomatenmark<br>
            500 ml	Tomatenpüree<br>
            Oregano<br>
            Salz und Pfeffer<br>
            1	Knoblauchzehe(n)<br>
            Paprikapulver<br>
            80 g	Margarine<br>
            80 g	Mehl<br>
            ½ Liter	Gemüsebrühe<br>
            ½ Liter	Milch<br>
            1 Pck.	Pizzakäse<br>
            Salz und Pfeffer<br>
            Muskat<br>
            1 Pck.	Lasagneplatte(n)<br>
          </ul></p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </base-card>
    </div>


  </div>




</template>

<script>
import BaseCard from '@/components/BaseCard.vue';
import PostCard from "@/components/PostCard.vue";

export default {
  components: {
    PostCard,
    BaseCard,
  },
  data(){
    return{
      image1: 'https://media.istockphoto.com/id/527439685/de/foto/spaghetti-bolognese.jpg?s=612x612&w=0&k=20&c=BNp5af9pbxg5vJh3fNa_uy8h1r7Ns254zdPikG2F2Fk=',
      image2: 'https://media.istockphoto.com/id/469381932/de/foto/bruschetta-mit-tomaten-und-basilikum.jpg?s=612x612&w=0&k=20&c=rcSUKXzUY_9NTDcmcd6L62gJqEeGCcrMxMHWytyQUag=',
      image3: 'https://media.istockphoto.com/id/979115792/de/foto/risotto-mit-pilzen.jpg?s=612x612&w=0&k=20&c=1zxxFzdcs4leJD47lwIaBy3TZR4pP77a6DqYElHXeYA=',
      image4: 'https://media.istockphoto.com/id/168246587/de/foto/lasagne-primavera.jpg?s=612x612&w=0&k=20&c=aVlRUJQeF8JBXizO2vz2IEjGP_8KI9BSb9EryPgddOA=',


    };
  },
};

</script>