<template>
  <div style="display: grid; grid-template-columns: 1fr 1fr;">
    <div>
      <BaseCardRestaurant :image="image1"
                          :rating="4.2"
                          :reviews="160"
                          dollar="$$$"
                          cuisine="Mexikanisch"
                          category="Bar">
        <!-- Individuelle Inhalte für die Slots -->
        <template v-slot:header>
          <h2>Restaurant 1</h2>
        </template>
        <template v-slot:subtitle>
          <p>Adresse 1</p>
        </template>
        <template v-slot:content>
          <p>Kleine Gerichte, Salate und Sandwiches in einem intimen Rahmen mit 12 Innenplätzen und Sitzplätzen auf der Terrasse.</p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>

    <div>
      <BaseCardRestaurant :image="image2"
                          :rating="4.8"
                          :reviews="120"
                          dollar="$"
                          cuisine="Mexikanisch"
                          category="Restaurant">
        <!-- Individuelle Inhalte für die Slots -->

        <template v-slot:header>
          <h2>Restaurant 2</h2>
        </template>
        <template v-slot:subtitle>
          <p>Adresse 2</p>
        </template>
        <template v-slot:content>
          <p>Kleine Gerichte, Salate und Sandwiches in einem intimen Rahmen mit 12 Innenplätzen und Sitzplätzen auf der Terrasse.</p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>
  </div>

  <div style="display: grid; grid-template-columns: 1fr 1fr;">
    <div>
      <BaseCardRestaurant :image="image3"
                          :rating="4.7"
                          :reviews="250"
                          dollar="$$$"
                          cuisine="Mexikanisch"
                          category="Bar">
        <!-- Individuelle Inhalte für die Slots -->
        <template v-slot:header>
          <h2>Restaurant 3</h2>
        </template>
        <template v-slot:subtitle>
          <p>Adresse 3</p>
        </template>
        <template v-slot:content>
          <p>Kleine Gerichte, Salate und Sandwiches in einem intimen Rahmen mit 12 Innenplätzen und Sitzplätzen auf der Terrasse.</p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>

    <div>
      <BaseCardRestaurant :image="image4"
                          :rating="3.8"
                          :reviews="20"
                          dollar="$$"
                          cuisine="Mexikanisch"
                          category="Bar">
        <!-- Individuelle Inhalte für die Slots -->

        <template v-slot:header>
          <h2>Restaurant 4</h2>
        </template>
        <template v-slot:subtitle>
          <p>Adresse 4</p>
        </template>
        <template v-slot:content>
          <p>Kleine Gerichte, Salate und Sandwiches in einem intimen Rahmen mit 12 Innenplätzen und Sitzplätzen auf der Terrasse.</p>
        </template>
        <template v-slot:footer>
          <small>Individueller Foooooooooooter</small>
        </template>
      </BaseCardRestaurant>
    </div>
  </div>
</template>

<script>
import BaseCardRestaurant from '@/components/BaseCardRestaurant.vue';

export default {
  components: {

    BaseCardRestaurant,
  },
  data(){
    return{
      image1: 'https://media.istockphoto.com/id/90086955/de/foto/speisen-im-freien.jpg?s=612x612&w=0&k=20&c=GishxBg13yx5-EMWKzlKKRHsb04y1cO0OmH2uklXrHk=',
      image2: 'https://media.istockphoto.com/id/466310308/de/foto/gro%C3%9Fe-familie-die-mahlzeit-zusammen-im-mexikanischen-restaurant.jpg?s=612x612&w=0&k=20&c=W3JHRlyaHhrsnPJsYt_APauWynuUeMHInWL9yUacZ0w=',
      image3: 'https://media.istockphoto.com/id/525498484/de/foto/freunde-essen-in-einem-mexikanischen-restaurant.jpg?s=612x612&w=0&k=20&c=ZhC3NigC-d7My5iaHbyQe9rizFskrLbyvGF6AlTMgZI=',
      image4: 'https://media.istockphoto.com/id/579438752/de/foto/cluj-napoca-rum%C3%A4nien-10-juli-2016.jpg?s=612x612&w=0&k=20&c=W0bmSluK24VsGjGRlFJIbco1nsVa6D2EYgpRU3hb_Cs=',


    };
  },
};

</script>